# ExpenseApp
Use "npm install" command to install the node_modules for the React project.
