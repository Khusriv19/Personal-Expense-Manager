
insert into user values (1,'Siamak', 'Codeengine11@gmail.com')
insert into user values (2,'John', 'John@john.com')
insert into user values (3,'Adam', 'adam@adam.com')


insert into category values (1,'Travel')
insert into category values (2,'Auto Loan')
insert into category  values (3,'Travel')


insert into expense values (100,'New York Business Trip','2019-06-16T17:00:00.000Z','New York',1,1)
insert into expense values (101,'Ford Mustang Payment','2019-06-15T15:00:00.000Z','Los Angeles',2,2)
insert into expense values(102,'Grand Canyon Trip With Family','2019-06-15T15:00:00.000Z','Arizona',3,1)
 

